console.log("mahscript script.js v1.0 - Módulo de Roteiro");
(function () {
    function getTheme() {
        const skin = localStorage.getItem("mahscript_skin") || "black";
        if (typeof mahThemes !== "undefined" && mahThemes[skin]) return mahThemes[skin];
        return { main: "#000000", border: "#333333" };
    }

    function injectScriptCSS() {
        document.getElementById("mahscript-script-module-style")?.remove();
        const style = document.createElement("style");
        style.id = "mahscript-script-module-style";
        style.textContent = `
            #mahscript-script-area { padding: 0 !important; height: 100% !important; display: flex !important; flex-direction: column !important; }
            .mah-script-top {
                height: 52px !important; min-height: 52px !important; display: flex !important; align-items: center !important;
                justify-content: space-between !important; padding: 0 18px !important;
                border-bottom: 1px solid rgba(255,255,255,0.15) !important; background: rgba(0,0,0,0.18) !important; box-sizing: border-box !important;
            }
            .mah-script-title { color: #ffffff !important; font-size: 15px !important; font-weight: 500 !important; letter-spacing: 0.3px !important; }
            #mah-script-list {
                padding: 12px !important; overflow-y: auto !important; flex: 1 !important; box-sizing: border-box !important;
                display: grid !important; grid-template-columns: 1fr !important; gap: 8px !important;
            }
            .mah-script-btn {
                background: rgba(255,255,255,0.08) !important; border: 1px solid rgba(255,255,255,0.08) !important;
                border-radius: 12px !important; color: #ffffff !important; padding: 14px 16px !important; cursor: pointer !important;
                display: flex !important; align-items: center !important; justify-content: flex-start !important;
                text-align: left !important; transition: all 0.2s !important; font-family: Arial, sans-serif !important; gap: 12px !important;
            }
            .mah-script-btn:hover { background: rgba(255,255,255,0.18) !important; transform: translateX(2px) !important; }
            .mah-script-btn-icon { 
                font-size: 13px !important; font-family: 'Courier New', monospace !important; font-weight: bold !important; 
                text-transform: uppercase !important; opacity: 0.7 !important; min-width: 60px !important;
            }
            .mah-script-btn-label { font-size: 13px !important; line-height: 1.2 !important; font-weight: 400 !important; }
        `;
        document.documentElement.appendChild(style);
    }

    window.ensureScriptUI = function() {
        const area = document.getElementById("mahscript-script-area");
        if (!area) return;
        injectScriptCSS();
        area.innerHTML = `
            <div id="mahscript-script-module">
                <div class="mah-script-top"><div class="mah-script-title">Roteiro</div></div>
                <div id="mah-script-list"></div>
            </div>`;
        renderScriptButtons();
    };

    function renderScriptButtons() {
        const list = document.getElementById("mah-script-list");
        if (!list) return;

        const buttons = [
            { label: "Slug Line (Cena)", icon: "INT./EXT.", type: "scene_heading" },
            { label: "Description (Ação)", icon: "AÇÃO", type: "action" },
            { label: "Character (Personagem)", icon: "NOME", type: "character" },
            { label: "Dialogue (Fala)", icon: "FALA", type: "dialogue" },
            { label: "Parenthesis", icon: "(EMOÇÃO)", type: "parenthetical" },
            { label: "Transition", icon: "CORTE PARA:", type: "transition" }
        ];

        list.innerHTML = buttons.map(btn => `
            <div class="mah-script-btn" data-type="${btn.type}">
                <div class="mah-script-btn-icon">${btn.icon}</div>
                <div class="mah-script-btn-label">${btn.label}</div>
            </div>
        `).join("");

        list.querySelectorAll(".mah-script-btn").forEach(btn => {
            btn.onclick = () => {
                if (typeof showToast === "function") showToast(`Inserindo ${btn.dataset.type}...`);
            };
        });
    }

    // Injeção do Botão Claquete
    function injectScriptButton() {
        if (document.getElementById("mahscript-btn-script")) return;
        const rightArea = document.querySelector(".docs-titlebar-buttons") || document.querySelector(".docs-titlebar-right");
        if (!rightArea) return;

        const clapperIcon = `<svg class="mahscript-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.2 6 3 11l-.9-2.4c-.3-1.1.3-2.2 1.3-2.5l13.7-3.6c1.1-.3 2.2.3 2.5 1.3l.6 2.2z"/><path d="m6.2 5.3 3.1 3.9"/><path d="m12.4 3.4 3.1 4"/><path d="M3 11h18v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2Z"/></svg>`;
        const btnHtml = `<button id="mahscript-btn-script" class="mahscript-native-btn" title="Roteiro">${clapperIcon}</button>`;
        
        const settingsBtn = document.getElementById("mahscript-btn-settings");
        if (settingsBtn) settingsBtn.insertAdjacentHTML('afterend', btnHtml);
        else rightArea.insertAdjacentHTML('beforeend', btnHtml);

        document.getElementById("mahscript-btn-script").onclick = (e) => {
            e.stopPropagation();
            if (typeof toggleSection === 'function') {
                toggleSection('mahscript-script-area');
            }
        };
    }

    const timer = setInterval(() => {
        const panel = document.getElementById('mahscript-docs-chapter-panel');
        if (panel) {
            if (!document.getElementById('mahscript-script-area')) {
                const scriptArea = document.createElement('div');
                scriptArea.id = 'mahscript-script-area';
                scriptArea.style.display = 'none';
                panel.appendChild(scriptArea);
            }
            injectScriptButton();
            clearInterval(timer);
        }
    }, 500);
})();