console.log("mahscript script.js v6.2 - Roteiro com UI estilo Capítulos");

(function () {

function showToastSafe(msg) {
    if (typeof showToast === "function") showToast(msg);
    else console.log(msg);
}

/* =========================
   CSS (AGORA IGUAL CAPÍTULOS)
========================= */
function injectScriptCSS() {

    if (document.getElementById("mahscript-script-module-style")) return;

    const style = document.createElement("style");
    style.id = "mahscript-script-module-style";

    style.textContent = `
        #mahscript-script-area{
            position: relative;
            height: 100%;
            display: flex;
            flex-direction: column;
            font-family: Arial, Roboto, sans-serif;
            color: #ffffff;
        }

        /* HEADER IGUAL CAPÍTULOS */
        .mah-script-top{
            height: 52px;
            min-height: 52px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 18px;
            border-bottom: 1px solid rgba(255,255,255,0.15);
            background: rgba(0,0,0,0.18);
            box-sizing: border-box;
        }

        .mah-script-title{
            font-size: 15px;
            font-weight: 500;
            letter-spacing: 0.3px;
        }

        /* LISTA IGUAL CAPÍTULOS */
        #mah-script-list{
            padding: 12px;
            overflow-y: auto;
            flex: 1;
            box-sizing: border-box;
        }

        /* ITEM IGUAL CAPÍTULOS */
        .mah-script-btn{
            min-height: 42px;
            border-radius: 9px;
            background: rgba(255,255,255,0.08);
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 7px 10px;
            margin-bottom: 7px;
            box-sizing: border-box;
            border: 1px solid rgba(255,255,255,0.08);
            cursor: pointer;
        }

        .mah-script-btn:hover{
            background: rgba(255,255,255,0.14);
        }

        .mah-script-btn-icon{
            min-width: 70px;
            font-size: 12px;
            font-family: monospace;
            opacity: 0.75;
        }

        .mah-script-btn-label{
            font-size: 13px;
            color: #ffffff;
        }

        .mahscript-native-btn{
            background: transparent;
            border: none;
            box-shadow: none;
            cursor: pointer;
            padding: 6px;
        }
    `;

    document.head.appendChild(style);
}

/* =========================
   UI
========================= */
window.ensureScriptUI = function () {

    const area = document.getElementById("mahscript-script-area");
    if (!area) return;

    injectScriptCSS();

    area.innerHTML = `
        <div id="mahscript-script-module">

            <div class="mah-script-top">
                <div class="mah-script-title">Roteiro</div>
            </div>

            <div id="mah-script-list"></div>

        </div>
    `;

    renderScriptButtons();
};

/* =========================
   BOTÕES
========================= */
function renderScriptButtons() {

    const list = document.getElementById("mah-script-list");
    if (!list) return;

    const buttons = [
        { label:"Slug Line", icon:"INT./EXT.", type:"scene_heading" },
        { label:"Description", icon:"AÇÃO", type:"action" },
        { label:"Character", icon:"NOME", type:"character" },
        { label:"Dialogue", icon:"FALA", type:"dialogue" },
        { label:"Parenthetical", icon:"(EMOÇÃO)", type:"parenthetical" },
        { label:"Transition", icon:"CORTE PARA:", type:"transition" }
    ];

    list.innerHTML = buttons.map(btn => `
        <div class="mah-script-btn" data-type="${btn.type}">
            <div class="mah-script-btn-icon">${btn.icon}</div>
            <div class="mah-script-btn-label">${btn.label}</div>
        </div>
    `).join("");

    list.querySelectorAll(".mah-script-btn").forEach(btn => {
        btn.onclick = () => {
            showToastSafe(`Inserindo ${btn.dataset.type}...`);
        };
    });
};

/* =========================
   FECHAR OUTROS MODOS (opcional)
========================= */
function closeAllModules() {

    const panel = document.getElementById("mahscript-docs-chapter-panel");
    if (!panel) return;

    panel.querySelectorAll(":scope > div").forEach(el => {
        el.style.display = "none";
    });
}

/* =========================
   BOTÃO NA TOOLBAR
========================= */
function injectScriptButton() {

    if (document.getElementById("mahscript-btn-script")) return;

    const rightArea =
        document.querySelector(".docs-titlebar-buttons") ||
        document.querySelector(".docs-titlebar-right");

    if (!rightArea) return;

    const btn = document.createElement("button");
    btn.id = "mahscript-btn-script";
    btn.className = "mahscript-native-btn";
    btn.title = "Roteiro";

    btn.innerHTML = `
        <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M20.2 6 3 11l-.9-2.4c-.3-1.1.3-2.2 1.3-2.5l13.7-3.6c1.1-.3 2.2.3 2.5 1.3l.6 2.2z"/>
            <path d="M3 11h18v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2Z"/>
        </svg>
    `;

    const settingsBtn = document.getElementById("mahscript-btn-settings");

    if (settingsBtn) {
        settingsBtn.insertAdjacentElement("afterend", btn);
    } else {
        rightArea.appendChild(btn);
    }

    btn.onclick = (e) => {

        e.preventDefault();
        e.stopPropagation();

        const scriptArea = document.getElementById("mahscript-script-area");
        if (!scriptArea) return;

        const isOpen = scriptArea.style.display === "block";

        closeAllModules();

        if (isOpen) {
            scriptArea.style.display = "none";
            return;
        }

        scriptArea.style.display = "block";
        window.ensureScriptUI();
    };
}

/* =========================
   INIT
========================= */
const timer = setInterval(() => {

    const panel = document.getElementById("mahscript-docs-chapter-panel");
    if (!panel) return;

    if (!document.getElementById("mahscript-script-area")) {

        const area = document.createElement("div");
        area.id = "mahscript-script-area";
        area.style.display = "none";

        panel.appendChild(area);
    }

    injectScriptButton();

    clearInterval(timer);

}, 500);

})();