console.log("mahscript panel-builder.js v1.0");
(function () {
    class MahScriptPanel {
        constructor() {
            this.panel = null;
            this.docId = window.location.href.match(/\/d\/([a-zA-Z0-9-_]+)/)?.[1] || 'unknown_doc';
            this.init();
        }
        init() {
            this.createPanelStructure();
            this.startDocumentObserver();
        }
        createPanelStructure() {
            if (document.getElementById('mahscript-docs-chapter-panel')) return;
            this.panel = document.createElement('aside');
            this.panel.id = 'mahscript-docs-chapter-panel';
            this.panel.innerHTML = `
                <div class="mahscript-chapter-header-row">
                    <div class="mahscript-chapter-header-title">Capítulos</div>
                    <button class="mahscript-chapter-add" id="mahscript-add-chapter" title="Adicionar guia">+</button>
                </div>
                <div id="mahscript-inline-prompt" style="display: none;">
                    <input type="text" id="mahscript-prompt-input" placeholder="Nome da guia...">
                    <div class="mahscript-prompt-actions">
                        <button id="mahscript-prompt-cancel" class="mahscript-prompt-btn">Cancelar</button>
                        <button id="mahscript-prompt-ok" class="mahscript-prompt-btn">OK</button>
                    </div>
                </div>
                <div id="mahscript-chapters-area" style="display: none;">
                    <div id="mahscript-chapter-list"></div>
                </div>
                <div id="mahscript-settings-section" style="display: none;"></div>
                <!-- CONTAINER DO ROTEIRO ADICIONADO AQUI -->
                <div id="mahscript-script-area" style="display: none;"></div>
            `;
            document.body.appendChild(this.panel);
            this.bindEvents();
        }
        startDocumentObserver() {
            const waitForLeftNav = setInterval(() => {
                const leftNav = document.querySelector('.navigation-widget');
                if (leftNav) {
                    clearInterval(waitForLeftNav);
                    this.leftNavObserver = new MutationObserver(() => { 
                        clearTimeout(this.syncTimeout); 
                        this.syncTimeout = setTimeout(() => {
                            this.syncMirror();
                        }, 300); 
                    });
                    this.leftNavObserver.observe(leftNav, { childList: true, subtree: true, attributes: true, attributeFilter: ['style'] });
                    this.syncMirror();
                }
            }, 500);

            const editor = document.querySelector('.kix-appview-editor');
            if (editor) {
                this.editorObserver = new MutationObserver(() => { 
                    clearTimeout(this.scanTimeout); 
                    this.scanTimeout = setTimeout(() => {
                        this.syncMirror();
                    }, 1500); 
                });
                this.editorObserver.observe(editor, { childList: true, subtree: true, characterData: true });
            }
        }
        syncMirror() {
            const container = document.getElementById('mahscript-chapter-list');
            if(!container) return;
            const nativeOutline = document.querySelector('.outlines-widget-chaptered');

            if (!nativeOutline) {
                container.innerHTML = '<div class="mahscript-chapter-empty">Nenhuma guia detectada.<br>Use o botão "+" para criar ou adicione Títulos no Docs.</div>';
                return;
            }

            const clone = nativeOutline.cloneNode(true);
            clone.querySelectorAll('[id]').forEach(el => el.removeAttribute('id'));
            clone.style.width = '100%';
            clone.style.color = '#ffffff'; 

            clone.querySelectorAll('[role="treeitem"], .chapter-item-label-and-buttons-container').forEach(item => {
                item.style.cursor = 'pointer';
                item.style.padding = '8px 4px';
                item.style.borderRadius = '6px';
                
                item.onmouseover = () => item.style.backgroundColor = 'rgba(255,255,255,0.1)';
                item.onmouseout = () => item.style.backgroundColor = 'transparent';
                
                item.onclick = (e) => {
                    e.stopPropagation();
                    const labelText = item.querySelector('.chapter-label-content')?.innerText;
                    if (labelText) {
                        const originals = Array.from(document.querySelectorAll('.chapter-item-label-and-buttons-container'));
                        const target = originals.find(o => o.querySelector('.chapter-label-content')?.innerText === labelText);
                        if (target) {
                            target.click();
                            target.scrollIntoView({ behavior: 'smooth', block: 'center' });
                        }
                    }
                };
            });

            container.innerHTML = '';
            container.appendChild(clone);
        }
        bindEvents() {
            const promptBox = document.getElementById('mahscript-inline-prompt');
            const promptInput = document.getElementById('mahscript-prompt-input');
            const promptOk = document.getElementById('mahscript-prompt-ok');
            const promptCancel = document.getElementById('mahscript-prompt-cancel');
            document.getElementById('mahscript-add-chapter').onclick = () => {
                promptBox.style.display = 'block';
                promptInput.value = `Guia ${Math.floor(Math.random() * 100)}`;
                promptInput.focus();
                promptInput.select();
            }; 

            const submitChapter = () => {
                const title = promptInput.value.trim();
                if (title) {
                    this.insertTextInDocs(title, true);
                    setTimeout(() => this.syncMirror(), 1500);
                }
                promptBox.style.display = 'none';
            };

            promptOk.onclick = submitChapter;
            promptCancel.onclick = () => { promptBox.style.display = 'none'; };
            promptInput.addEventListener('keypress', (e) => { if (e.key === 'Enter') submitChapter(); });
        }
        insertTextInDocs(text, isChapter = false) {
            const editor = document.querySelector('.kix-appview-editor') || document.querySelector('[contenteditable="true"]');
            if (!editor) return;
            const rect = editor.getBoundingClientRect();
            const clickEvent = new MouseEvent('click', { bubbles: true, cancelable: true, view: window, clientX: rect.left + rect.width / 2, clientY: rect.top + rect.height / 2 });
            editor.dispatchEvent(clickEvent);
            editor.focus();
            setTimeout(() => {
                try {
                    if (isChapter) {
                        editor.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, ctrlKey: true, bubbles: true }));
                        editor.dispatchEvent(new KeyboardEvent('keypress', { key: 'Enter', keyCode: 13, ctrlKey: true, bubbles: true }));
                        editor.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', keyCode: 13, ctrlKey: true, bubbles: true }));
                    }
                    const success = document.execCommand('insertText', false, text);
                    if (success) return;
                } catch (e) {}

                try {
                    const clipboardData = new DataTransfer();
                    clipboardData.setData('text/plain', isChapter ? `\n\n${text}\n\n` : text);
                    const pasteEvent = new ClipboardEvent('paste', { bubbles: true, cancelable: true, clipboardData: clipboardData });
                    editor.dispatchEvent(pasteEvent);
                } catch (e) { console.error("Falha ao inserir texto", e); }
            }, 150);
        }
    }

    window.mahPanelInstance = new MahScriptPanel();
})();