console.log("mahscript theme-manager.js v1.0");
(function () {
    const mahThemes = {
        black: { main: "#000000", border: "#333333", pageArea: "#f5f5f5", inputBorder: "#dadce0", rulerRotate: "180deg", shareBg: "#f3f4f6", shareText: "#111827" },
        darkgray: { main: "#2f3136", border: "#44474d", pageArea: "#d9d9d9", inputBorder: "#bdbdbd", rulerRotate: "0deg", shareBg: "#e0e0e0", shareText: "#2f3136" },
        midnight: { main: "#0f172a", border: "#1e293b", pageArea: "#dbeafe", inputBorder: "#bfdbfe", rulerRotate: "200deg", shareBg: "#dbeafe", shareText: "#0f172a" },
        forest: { main: "#14532d", border: "#166534", pageArea: "#dcfce7", inputBorder: "#bbf7d0", rulerRotate: "120deg", shareBg: "#dcfce7", shareText: "#14532d" },
        purple: { main: "#4c1d95", border: "#5b21b6", pageArea: "#f3e8ff", inputBorder: "#e9d5ff", rulerRotate: "270deg", shareBg: "#ede9fe", shareText: "#4c1d95" },
        coffee: { main: "#5d4037", border: "#6d4c41", pageArea: "#fef7ed", inputBorder: "#fed7aa", rulerRotate: "30deg", shareBg: "#fed7aa", shareText: "#3e2723" },
        silver: { main: "#616161", border: "#757575", pageArea: "#f3f4f6", inputBorder: "#d1d5db", rulerRotate: "0deg", shareBg: "#e5e7eb", shareText: "#263238" },
        crimson: { main: "#7f1d1d", border: "#991b1b", pageArea: "#fee2e2", inputBorder: "#fecaca", rulerRotate: "0deg", shareBg: "#fee2e2", shareText: "#7f1d1d" },
        amber: { main: "#78350f", border: "#92400e", pageArea: "#fef3c7", inputBorder: "#fde68a", rulerRotate: "45deg", shareBg: "#fef3c7", shareText: "#78350f" },
        teal: { main: "#134e4a", border: "#115e59", pageArea: "#ccfbf1", inputBorder: "#99f6e4", rulerRotate: "180deg", shareBg: "#ccfbf1", shareText: "#134e4a" },
        slate: { main: "#1e293b", border: "#334155", pageArea: "#f1f5f9", inputBorder: "#cbd5e1", rulerRotate: "0deg", shareBg: "#f1f5f9", shareText: "#1e293b" },
        rose: { main: "#881337", border: "#9f1239", pageArea: "#ffe4e6", inputBorder: "#fecdd3", rulerRotate: "330deg", shareBg: "#ffe4e6", shareText: "#881337" },
        lavanda: { main: "#7c3aed", border: "#6d28d9", pageArea: "#f5f3ff", inputBorder: "#ddd6fe", rulerRotate: "270deg", shareBg: "#ede9fe", shareText: "#4c1d95" },
        carmim: { main: "#e11d48", border: "#be123c", pageArea: "#fff1f2", inputBorder: "#fecdd3", rulerRotate: "0deg", shareBg: "#ffe4e6", shareText: "#881337" },
        oliva: { main: "#4d7c0f", border: "#365314", pageArea: "#f7fee7", inputBorder: "#d9f99d", rulerRotate: "120deg", shareBg: "#ecfccb", shareText: "#365314" },
        safira: { main: "#2563eb", border: "#1d4ed8", pageArea: "#eff6ff", inputBorder: "#bfdbfe", rulerRotate: "180deg", shareBg: "#dbeafe", shareText: "#1e3a8a" },
        carvao: { main: "#d4d4d8", border: "#a1a1aa", pageArea: "#27272a", inputBorder: "#52525b", rulerRotate: "0deg", shareBg: "#3f3f46", shareText: "#fafafa" },
        pessego: { main: "#f97316", border: "#ea580c", pageArea: "#fff7ed", inputBorder: "#fed7aa", rulerRotate: "45deg", shareBg: "#ffedd5", shareText: "#7c2d12" }
    };

    let currentTheme = localStorage.getItem('mahscript_skin') || 'black';

    function makeMahSkin(t) {
        return `
            html, body, #docs-chrome, #docs-editor, .docs-gm, .docs-shell,
            .docs-chrome-top, .docs-chrome-bottom, .docs-header-container,
            .docs-titlebar, .docs-titlebar-buttons, .docs-titlebar-center,
            .docs-titlebar-right, .docs-title-outer, .docs-menubar,
            .docs-toolbar-wrapper, .goog-toolbar, [class*="toolbar"], #gb {
                background-color: ${t.main} !important;
            }
            .docs-titlebar, .docs-toolbar-wrapper, .docs-header-container, .docs-chrome-top {
                border-bottom: 1px solid ${t.border} !important;
            }
            .kix-appview-editor, .kix-page-content-wrapper {
                background-color: ${t.pageArea} !important;
            }
            .docs-menubar *, .docs-toolbar-wrapper *, .goog-toolbar *, [class*="toolbar"] *, .docs-outline-widget *, #gb * {
                color: #ffffff !important; fill: #ffffff !important; font-weight: 400 !important;
            }
            svg:not(.mahscript-icon), svg:not(.mahscript-icon) *, .docs-icon-img, .docs-icon, .goog-toolbar-button svg, button svg,
            [role="button"] svg, .docs-material svg, .material-icons-extended,
            .docs-toolbar-button-icon svg, [class*="icon"] svg, [class*="icon"] img,
            img[src*="icon"], i.material-icons, span.material-symbols {
                filter: brightness(0) invert(1) !important; fill: #ffffff !important; color: #ffffff !important; stroke: #ffffff !important;
            }
            .docs-title-input, input.docs-title-input {
                background: transparent !important; color: #ffffff !important; -webkit-text-fill-color: #ffffff !important;
                border: none !important; box-shadow: none !important; outline: none !important; opacity: 1 !important;
            }
            .docs-title-input-label, .docs-title-input-label-inner { display: none !important; visibility: hidden !important; opacity: 0 !important; }
            input[placeholder*="Menus"], input[aria-label*="Menus"], input[placeholder*="Menu"], input[aria-label*="Menu"] {
                color: #ffffff !important; -webkit-text-fill-color: #ffffff !important; background: transparent !important; opacity: 1 !important;
            }
            input[placeholder*="Menus"]::placeholder, input[aria-label*="Menus"]::placeholder,
            input[placeholder*="Menu"]::placeholder, input[aria-label*="Menu"]::placeholder {
                color: #ffffff !important; -webkit-text-fill-color: #ffffff !important; opacity: 1 !important;
            }
            .docs-icon-img-container, .docs-icon-img, .docs-icon { background-color: transparent !important; box-shadow: none !important; }
            
            .mahscript-native-btn {
                width: 36px !important; height: 36px !important; margin: 0 4px !important;
                border: none !important; border-radius: 50% !important;
                background-color: transparent !important;
                display: inline-flex !important; align-items: center !important; justify-content: center !important; 
                cursor: pointer !important; z-index: 999999 !important;
                transition: background-color 0.2s ease !important;
                vertical-align: middle !important; padding: 0 !important; line-height: 1 !important;
            }
            .mahscript-native-btn:hover { background-color: rgba(255, 255, 255, 0.15) !important; }
            .mahscript-native-btn svg { 
                width: 20px !important; height: 20px !important; fill: none !important; stroke: #ffffff !important; 
                stroke-width: 2 !important; stroke-linecap: round !important; stroke-linejoin: round !important; display: block !important; 
            }
            
            .docs-titlebar-buttons button:not(.mahscript-native-btn),
            .docs-titlebar-right button:not(.mahscript-native-btn),
            [role="button"]:not(.mahscript-native-btn) svg {
                fill: none !important; stroke: #ffffff !important; stroke-width: 2 !important;
            }
            .docs-titlebar-buttons button:not(.mahscript-native-btn):hover, 
            .docs-titlebar-right button:not(.mahscript-native-btn):hover {
                background-color: rgba(255, 255, 255, 0.15) !important;
            }
            
            #mahscript-toast {
                position: fixed !important; bottom: 24px !important; right: 306px !important;
                background: ${t.main} !important; color: #ffffff !important;
                padding: 12px 20px !important; border-radius: 8px !important;
                box-shadow: 0 8px 24px rgba(0,0,0,0.3) !important; z-index: 9999999 !important;
                font-family: Arial, Roboto, sans-serif !important; font-size: 13px !important; font-weight: 400 !important;
                display: none !important; align-items: center !important; gap: 10px !important;
                border: 1px solid ${t.border} !important; animation: slideIn 0.3s ease !important;
            }
            @keyframes slideIn { from { transform: translateX(400px); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
            
            #mahscript-delete-modal {
                position: fixed !important; top: 50% !important; left: 50% !important;
                transform: translate(-50%, -50%) !important; background: ${t.main} !important; color: #ffffff !important;
                padding: 24px !important; border-radius: 12px !important;
                box-shadow: 0 20px 60px rgba(0,0,0,0.5) !important; z-index: 99999999 !important;
                font-family: Arial, Roboto, sans-serif !important; min-width: 320px !important; border: 1px solid ${t.border} !important;
            }
            #mahscript-delete-modal h3 { margin: 0 0 12px 0 !important; font-size: 16px !important; font-weight: 500 !important; color: #ffffff !important; }
            #mahscript-delete-modal p { margin: 0 0 20px 0 !important; font-size: 13px !important; opacity: 0.9 !important; line-height: 1.5 !important; }
            .mahscript-modal-actions { display: flex !important; gap: 10px !important; justify-content: flex-end !important; }
            .mahscript-modal-btn { padding: 8px 16px !important; border-radius: 6px !important; border: none !important; font-size: 13px !important; font-weight: 400 !important; cursor: pointer !important; transition: opacity 0.2s !important; }
            .mahscript-modal-btn:hover { opacity: 0.8 !important; }
            #mahscript-delete-cancel { background: rgba(255,255,255,0.1) !important; color: #ffffff !important; }
            #mahscript-delete-confirm { background: #ef4444 !important; color: #ffffff !important; }
            
            /* PAINEL LATERAL E SEÇÕES */
            #mahscript-settings-section { padding: 16px !important; overflow-y: auto !important; max-height: calc(100vh - 200px) !important; }
            .mahscript-skins-title { margin: 0 0 12px 0 !important; font-size: 13px !important; letter-spacing: 0.5px !important; color: #ffffff !important; font-weight: 400 !important; text-transform: none !important; }
            
            .mahscript-theme-box {
                background-color: #ffffff !important; border-radius: 12px !important; padding: 12px !important;
                margin-bottom: 16px !important; box-shadow: 0 4px 12px rgba(0,0,0,0.15) !important;
                display: grid !important; grid-template-columns: repeat(6, 1fr) !important; gap: 8px !important; justify-items: center !important;
            }
            .mahscript-theme-circle {
                width: 20px !important; height: 20px !important; border-radius: 50% !important;
                border: 2px solid transparent !important; cursor: pointer !important;
                transition: transform 0.2s ease, border-color 0.2s ease !important;
                box-shadow: 0 1px 3px rgba(0,0,0,0.2) !important;
            }
            .mahscript-theme-circle:hover { transform: scale(1.2) !important; }
            .mahscript-theme-circle.active {
                border-color: #000000 !important; transform: scale(1.1) !important;
                box-shadow: 0 0 0 2px #ffffff, 0 0 0 4px #000000 !important;
            }
            
            .mah-form label { display: block !important; font-size: 13px !important; color: #ffffff !important; margin-top: 14px !important; margin-bottom: 6px !important; font-weight: 400 !important; text-transform: none !important; }
            
            #mahscript-settings-section .mah-form input,
            #mahscript-settings-section .mah-form textarea,
            #mahscript-settings-section .mah-form select {
                width: 100% !important; padding: 10px 12px !important; border-radius: 6px !important;
                border: 1px solid ${t.border} !important; background: #ffffff !important; color: #000000 !important;
                -webkit-text-fill-color: #000000 !important; font-size: 13px !important; box-sizing: border-box !important; 
                outline: none !important; font-family: Arial, Roboto, sans-serif !important; transition: border-color 0.2s !important;
            }
            #mahscript-settings-section .mah-form input:focus,
            #mahscript-settings-section .mah-form textarea:focus,
            #mahscript-settings-section .mah-form select:focus { border-color: rgba(0,0,0,0.4) !important; }
            
            .mah-btn-save { margin-top: 18px !important; padding: 10px !important; background: rgba(255,255,255,0.15) !important; color: #ffffff !important; border: 1px solid rgba(255,255,255,0.2) !important; border-radius: 6px !important; cursor: pointer !important; font-weight: 400 !important; width: 100% !important; transition: all 0.2s !important; font-size: 13px !important; letter-spacing: 0.5px !important; }
            .mah-btn-save:hover { background: rgba(255,255,255,0.25) !important; }
            
            .mah-cover-actions { display: flex !important; gap: 8px !important; margin-bottom: 12px !important; }
            .mah-cover-preview { width: 100% !important; height: 140px !important; background: rgba(255,255,255,0.04) !important; border-radius: 8px !important; display: flex !important; align-items: center !important; justify-content: center !important; overflow: hidden !important; margin-bottom: 12px !important; border: 1px dashed ${t.border} !important; flex-direction: column !important; gap: 10px !important; }
            .mah-cover-preview img { max-width: 100% !important; max-height: 100% !important; object-fit: cover !important; }
            .mah-placeholder { color: #aaaaaa !important; font-size: 13px !important; }
            
            #mahscript-inline-prompt { padding: 12px 16px !important; border-bottom: 1px solid ${t.border} !important; background: rgba(0,0,0,0.2) !important; }
            #mahscript-prompt-input { width: 100% !important; padding: 10px 12px !important; border-radius: 6px !important; border: 1px solid ${t.border} !important; background: rgba(255,255,255,0.06) !important; color: #ffffff !important; font-size: 13px !important; box-sizing: border-box !important; margin-bottom: 10px !important; outline: none !important; }
            #mahscript-prompt-input:focus { border-color: rgba(255,255,255,0.4) !important; }
            .mahscript-prompt-actions { display: flex !important; gap: 8px !important; justify-content: flex-end !important; }
            .mahscript-prompt-btn { padding: 7px 14px !important; border-radius: 6px !important; border: none !important; font-size: 13px !important; font-weight: 400 !important; cursor: pointer !important; transition: opacity 0.2s !important; }
            .mahscript-prompt-btn:hover { opacity: 0.8 !important; }
            #mahscript-prompt-cancel { background: rgba(255,255,255,0.1) !important; color: #ffffff !important; }
            #mahscript-prompt-ok { background: rgba(255,255,255,0.2) !important; color: #ffffff !important; }
            
            [aria-label*="Compartilhar"], [aria-label*="Share"], [guidedhelpid*="share"], .docs-titlebar-share-client-button, .docs-titlebar-share-client-button-outer, [aria-label*="Edição"], [aria-label*="Editing"], [aria-label*="Editar"], [aria-label*="modo"], [aria-label*="Mode"], [guidedhelpid*="mode"], .docs-editing-mode-button, .docs-mode-switcher, .docs-toolbar-mode-switcher { background-color: ${t.shareBg} !important; color: ${t.shareText} !important; border: none !important; filter: none !important; }
            [aria-label*="Compartilhar"], [aria-label*="Share"], [guidedhelpid*="share"], .docs-titlebar-share-client-button, .docs-titlebar-share-client-button-outer { border-radius: 24px 0 0 24px !important; }
            [aria-label*="Edição"], [aria-label*="Editing"], [aria-label*="Editar"], [aria-label*="modo"], [aria-label*="Mode"], [guidedhelpid*="mode"], .docs-editing-mode-button, .docs-mode-switcher, .docs-toolbar-mode-switcher { border-radius: 24px !important; }
            .docs-titlebar-share-client-button + div, .docs-titlebar-share-client-button-outer + div, [aria-label*="Compartilhar"] + div, [aria-label*="Share"] + div { background-color: ${t.shareBg} !important; color: ${t.shareText} !important; border-radius: 0 24px 24px 0 !important; margin-left: 1px !important; }
            [aria-label*="Compartilhar"] *, [aria-label*="Share"] *, [guidedhelpid*="share"] *, .docs-titlebar-share-client-button *, .docs-titlebar-share-client-button-outer *, [aria-label*="Edição"] *, [aria-label*="Editing"] *, [aria-label*="Editar"] *, [aria-label*="modo"] *, [aria-label*="Mode"] *, [guidedhelpid*="mode"] *, .docs-editing-mode-button *, .docs-mode-switcher *, .docs-toolbar-mode-switcher * { color: ${t.shareText} !important; fill: ${t.shareText} !important; stroke: ${t.shareText} !important; filter: none !important; background: transparent !important; }
            
            .docs-document-tabs, .docs-document-tabs-container, [aria-label*="Guias no documento"], [aria-label*="Document tabs"] { background-color: ${t.main} !important; color: #ffffff !important; }
            .docs-document-tabs *, .docs-document-tabs-container *, [aria-label*="Guias no documento"] *, [aria-label*="Document tabs"] * { color: #ffffff !important; fill: #ffffff !important; stroke: #ffffff !important; }
            .docs-document-tabs div:not([aria-selected="true"]), .docs-document-tabs-container div:not([aria-selected="true"]), [aria-label*="Guias no documento"] div:not([aria-selected="true"]), [aria-label*="Document tabs"] div:not([aria-selected="true"]) { background-color: transparent !important; }
            .docs-document-tabs [aria-selected="true"], .docs-document-tabs-container [aria-selected="true"], [aria-label*="Guia 1"], [aria-label*="Tab 1"] { background-color: ${t.shareBg} !important; color: ${t.shareText} !important; border-radius: 24px !important; border: none !important; box-shadow: none !important; }
            .docs-document-tabs [aria-selected="true"] *, .docs-document-tabs-container [aria-selected="true"] *, [aria-label*="Guia 1"] *, [aria-label*="Tab 1"] * { color: ${t.shareText} !important; fill: ${t.shareText} !important; stroke: ${t.shareText} !important; }
            
            img[src*="googleusercontent"], .gb_Aa, .gb_Pa, .gbii { filter: none !important; background-color: transparent !important; border-radius: 50% !important; }
            input[type="text"]:not(.docs-title-input), input[type="search"], textarea, [contenteditable="true"]:not(.kix-page-paginated *) { background-color: #ffffff !important; color: #000000 !important; border: 1px solid ${t.inputBorder} !important; caret-color: #000000 !important; }
            .kix-ruler { background-color: ${t.pageArea} !important; filter: invert(1) hue-rotate(${t.rulerRotate}); }
            .kix-page-paginated { background-color: #ffffff !important; color: #000000 !important; box-shadow: 0 0 15px rgba(0,0,0,0.15) !important; }
            .kix-page-paginated * { background: transparent !important; color: inherit !important; }
            
            /* PAINEL DIREITO FIXO */
            #mahscript-docs-chapter-panel {
                position: fixed !important; right: 0 !important; width: 282px !important; top: 128px !important;
                height: calc(100vh - 128px) !important; z-index: 9999997 !important;
                background: ${t.main} !important; color: #ffffff !important;
                font-family: Arial, Roboto, sans-serif !important;
                display: flex !important; flex-direction: column !important; overflow: hidden !important;
                border-left: 1px solid ${t.border} !important;
            }
            #mahscript-docs-chapter-panel *:not(input):not(textarea):not(select) { color: #ffffff !important; fill: #ffffff !important; stroke: #ffffff !important; }
            
            .mahscript-chapter-header-row {
                display: none !important; align-items: center !important; justify-content: space-between !important;
                padding: 12px 20px !important; color: #ffffff !important;
                border-bottom: 1px solid ${t.border} !important; background: rgba(0,0,0,0.15) !important;
            }
            .mahscript-chapter-header-title { color: #ffffff !important; font-size: 13px !important; font-weight: 400 !important; letter-spacing: 0.5px !important; text-transform: none !important; }
            .mahscript-chapter-add { border: none !important; background: transparent !important; color: #ffffff !important; width: 28px !important; height: 28px !important; display: flex !important; align-items: center !important; justify-content: center !important; font-size: 20px !important; cursor: pointer !important; border-radius: 50% !important; padding: 0 !important; }
            .mahscript-chapter-add:hover { background: rgba(255,255,255,.12) !important; }
            
            #mahscript-chapter-list { display: flex !important; flex-direction: column !important; gap: 4px !important; padding: 12px 16px !important; overflow-y: auto !important; flex: 1 !important; }
            .mahscript-chapter-item { min-height: 42px !important; border-radius: 8px !important; background: rgba(255,255,255,0.05) !important; color: #ffffff !important; display: flex !important; align-items: center !important; padding: 0 16px !important; cursor: pointer !important; font-size: 13px !important; font-weight: 400 !important; user-select: none !important; transition: all 0.15s ease !important; border: 1px solid transparent !important; }
            .mahscript-chapter-item:hover { background: rgba(255,255,255,0.1) !important; border-color: rgba(255,255,255,0.1) !important; }
            .mahscript-chapter-item:active { background: rgba(255,255,255,0.15) !important; }
            .mahscript-chapter-title-text { flex: 1 !important; color: #ffffff !important; font-size: 13px !important; white-space: nowrap !important; overflow: hidden !important; text-overflow: ellipsis !important; }
            .mahscript-chapter-empty { padding: 20px !important; color: #ffffff !important; font-style: italic !important; font-size: 13px !important; opacity: 0.6 !important; text-align: center !important; }
        `;
    }

    window.showToast = function(message) {
        const toast = document.getElementById('mahscript-toast');
        if (toast) toast.remove();
        const newToast = document.createElement('div');
        newToast.id = 'mahscript-toast';
        newToast.textContent = message;
        document.body.appendChild(newToast);
        newToast.style.display = 'flex';
        setTimeout(() => { newToast.style.opacity = '0'; newToast.style.transition = 'opacity 0.3s'; setTimeout(() => newToast.remove(), 300); }, 3000);
    };

    window.showDeleteModal = function(chapterTitle, onConfirm) {
        const modal = document.createElement('div');
        modal.id = 'mahscript-delete-modal';
        modal.innerHTML = `<h3>Excluir Capítulo</h3><p>Tem certeza que deseja excluir "<strong>${chapterTitle}</strong>"? Esta ação não pode ser desfeita.</p><div class="mahscript-modal-actions"><button id="mahscript-delete-cancel" class="mahscript-modal-btn">Cancelar</button><button id="mahscript-delete-confirm" class="mahscript-modal-btn">Excluir Permanentemente</button></div>`;
        document.body.appendChild(modal);
        document.getElementById('mahscript-delete-cancel').onclick = () => modal.remove();
        document.getElementById('mahscript-delete-confirm').onclick = () => { modal.remove(); if (onConfirm) onConfirm(); };
    };

    window.applyMahSkin = function(skinName) {
        document.getElementById("mahscript-style")?.remove();
        if (!mahThemes[skinName]) return;
        const style = document.createElement("style");
        style.id = "mahscript-style";
        style.textContent = makeMahSkin(mahThemes[skinName]);
        document.documentElement.appendChild(style);
        currentTheme = skinName;
        localStorage.setItem('mahscript_skin', skinName);
        injectNativeButtons();
    };

    window.populateThemesList = function(containerId) {
        const container = document.getElementById(containerId);
        if (!container) return;
        container.innerHTML = '';
        Object.entries(mahThemes).forEach(([key, theme]) => {
            const circle = document.createElement("div");
            circle.className = "mahscript-theme-circle";
            circle.style.backgroundColor = theme.main;
            circle.setAttribute("data-theme", key);
            const displayName = key.charAt(0).toUpperCase() + key.slice(1);
            circle.title = displayName;
            if (key === currentTheme) circle.classList.add("active");
            circle.onclick = () => { 
                applyMahSkin(key); 
                document.querySelectorAll('.mahscript-theme-circle').forEach(c => c.classList.remove('active')); 
                circle.classList.add('active'); 
            };
            container.appendChild(circle);
        });
    };

    function injectNativeButtons() {
        ['mahscript-btn-skins', 'mahscript-btn-settings', 'mahscript-btn-chapters', 'mahscript-btn-script'].forEach(id => { document.getElementById(id)?.remove(); });
        const rightArea = document.querySelector(".docs-titlebar-buttons") || document.querySelector(".docs-titlebar-right");
        if (!rightArea) return;
        const icons = {
            settings: '<svg class="mahscript-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
            chapters: '<svg class="mahscript-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>',
            script: '<svg class="mahscript-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.2 6 3 11l-.9-2.4c-.3-1.1.3-2.2 1.3-2.5l13.7-3.6c1.1-.3 2.2.3 2.5 1.3l.6 2.2z"/><path d="m6.2 5.3 3.1 3.9"/><path d="m12.4 3.4 3.1 4"/><path d="M3 11h18v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2Z"/></svg>'
        };
        
        const buttonsHtml = `
            <button id="mahscript-btn-chapters" class="mahscript-native-btn" title="Capítulos">${icons.chapters}</button>
            <button id="mahscript-btn-script" class="mahscript-native-btn" title="Roteiro">${icons.script}</button>
            <button id="mahscript-btn-settings" class="mahscript-native-btn" title="Configurações">${icons.settings}</button>
        `;
        rightArea.insertAdjacentHTML('afterbegin', buttonsHtml);
        
        document.getElementById('mahscript-btn-chapters').onclick = (e) => { e.stopPropagation(); toggleSection('mahscript-chapters-area'); };
        document.getElementById('mahscript-btn-script').onclick = (e) => { e.stopPropagation(); toggleSection('mahscript-script-area'); };
        document.getElementById('mahscript-btn-settings').onclick = (e) => { e.stopPropagation(); toggleSection('mahscript-settings-section'); };
    }

    // Inicialização automática do tema ao carregar
    if (document.readyState !== 'loading') {
        applyMahSkin(currentTheme);
    } else {
        document.addEventListener('DOMContentLoaded', () => applyMahSkin(currentTheme));
    }

    chrome.runtime.onMessage.addListener((msg) => { if (msg?.type === "applySkin") applyMahSkin(msg.skin); });
})();