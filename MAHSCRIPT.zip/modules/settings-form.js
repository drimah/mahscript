console.log("mahscript settings-form.js v1.0");
(function () {
    window.renderSettingsForm = function() {
        const container = document.getElementById("mahscript-settings-section");
        if (!container) return;
        
        const docId = window.location.href.match(/\/d\/([a-zA-Z0-9-_]+)/)?.[1] || 'unknown';
        const meta = JSON.parse(localStorage.getItem(`mah_meta_${docId}`) || '{}');
        
        container.innerHTML = `
            <h3 class="mahscript-skins-title">Configurações</h3>
            <div class="mah-form">
                <div class="mah-cover-preview">
                    ${meta.cover ? `<img src="${meta.cover}" />` : '<div class="mah-placeholder">Sem Capa</div>'}
                </div>
                <div class="mah-cover-actions">
                    <button class="mah-btn-save" id="mah-cover-trigger-btn" style="margin-top:0; flex:1;">${meta.cover ? 'Trocar Capa' : 'Adicionar Capa'}</button>
                    ${meta.cover ? '<button class="mah-btn-save" id="mah-cover-remove-btn" style="margin-top:0; flex:1; background: rgba(239,68,68,0.3) !important; border-color: rgba(239,68,68,0.5) !important;">Remover Capa</button>' : ''}
                </div>
                <input type="file" id="mah-cover-input" accept="image/*" style="display:none">
                <label>Título da Obra</label>
                <input type="text" id="mah-title" value="${meta.title || ''}">
                <label>Autor</label>
                <input type="text" id="mah-author" value="${meta.author || ''}">
                <label>Formato</label>
                <select id="mah-format">
                    <option value="A5" ${meta.format === 'A5' ? 'selected' : ''}>A5 (Livro Padrão)</option>
                    <option value="A4" ${meta.format === 'A4' ? 'selected' : ''}>A4 (Documento)</option>
                    <option value="Kindle" ${meta.format === 'Kindle' ? 'selected' : ''}>Kindle (Ebook)</option>
                    <option value="6x9" ${meta.format === '6x9' ? 'selected' : ''}>6" x 9" (Amazon KDP)</option>
                </select>
                <label style="margin-top: 20px;">Temas</label>
                <div class="mahscript-theme-box" id="settings-theme-selector"></div>
            </div>`;
            
        populateThemesList('settings-theme-selector');
        document.getElementById('mah-cover-trigger-btn').onclick = () => document.getElementById('mah-cover-input').click();
        const removeBtn = document.getElementById('mah-cover-remove-btn');
        if (removeBtn) removeBtn.onclick = removeCover;
        
        document.getElementById('mah-cover-input').addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (evt) => {
                    const img = new Image();
                    img.onload = () => {
                        const canvas = document.createElement('canvas');
                        const ctx = canvas.getContext('2d');
                        const maxWidth = 800;
                        const scale = Math.min(maxWidth / img.width, 1);
                        canvas.width = img.width * scale;
                        canvas.height = img.height * scale;
                        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                        const resizedDataUrl = canvas.toDataURL('image/jpeg', 0.8);
                        
                        const docId = window.location.href.match(/\/d\/([a-zA-Z0-9-_]+)/)?.[1] || 'unknown';
                        const meta = JSON.parse(localStorage.getItem(`mah_meta_${docId}`) || '{}');
                        meta.cover = resizedDataUrl;
                        localStorage.setItem(`mah_meta_${docId}`, JSON.stringify(meta));
                        
                        insertCoverImage(resizedDataUrl);
                        renderSettingsForm();
                        showToast('Capa processada e otimizada!');
                    };
                    img.src = evt.target.result;
                };
                reader.readAsDataURL(file);
            }
        });

        document.getElementById('mah-title').addEventListener('input', saveSettingsData);
        document.getElementById('mah-author').addEventListener('input', saveSettingsData);
        document.getElementById('mah-format').addEventListener('change', saveSettingsData);
    };

    function removeCover() {
        const docId = window.location.href.match(/\/d\/([a-zA-Z0-9-_]+)/)?.[1] || 'unknown';
        const meta = JSON.parse(localStorage.getItem(`mah_meta_${docId}`) || '{}');
        delete meta.cover;
        localStorage.setItem(`mah_meta_${docId}`, JSON.stringify(meta));
        renderSettingsForm();
        showToast('Capa removida!');
    }

    function insertCoverImage(imageData) {
        const editor = document.querySelector('.kix-appview-editor');
        if (!editor) return;
        const rect = editor.getBoundingClientRect();
        editor.dispatchEvent(new MouseEvent('click', { 
            bubbles: true, cancelable: true, view: window, 
            clientX: rect.left + rect.width / 2, 
            clientY: rect.top + rect.height / 2 
        }));
        editor.focus();

        setTimeout(() => {
            try {
                const firstChild = editor.firstChild;
                if (firstChild) {
                    const range = document.createRange();
                    range.setStart(firstChild, 0);
                    range.collapse(true);
                    const sel = window.getSelection();
                    sel.removeAllRanges();
                    sel.addRange(range);
                }
                document.execCommand('insertImage', false, imageData);
                setTimeout(() => {
                    const insertedImg = editor.querySelector('img[src^="data:image"]');
                    if (insertedImg) {
                        insertedImg.style.width = '595pt';
                        insertedImg.style.height = '842pt';
                        insertedImg.style.maxWidth = 'none';
                        insertedImg.style.maxHeight = 'none';
                        const pageBreak = document.createElement('div');
                        pageBreak.style.pageBreakAfter = 'always';
                        pageBreak.style.height = '0';
                        pageBreak.style.clear = 'both';
                        insertedImg.parentNode.insertBefore(pageBreak, insertedImg.nextSibling);
                        showToast('Capa inserida em tamanho página cheia!');
                    } else {
                        showToast('Capa inserida (ajuste manual pode ser necessário).');
                    }
                }, 500);
            } catch (e) {
                console.error('Erro ao inserir capa:', e);
                showToast('Erro ao inserir capa.');
            }
        }, 300);
    }

    function saveSettingsData() {
        const docId = window.location.href.match(/\/d\/([a-zA-Z0-9-_]+)/)?.[1] || 'unknown';
        const meta = {
            title: document.getElementById('mah-title').value,
            author: document.getElementById('mah-author').value,
            format: document.getElementById('mah-format').value
        };
        const existing = JSON.parse(localStorage.getItem(`mah_meta_${docId}`) || '{}');
        localStorage.setItem(`mah_meta_${docId}`, JSON.stringify({...existing, ...meta}));
    }
})();