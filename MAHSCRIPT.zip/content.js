console.log("mahscript content.js v10.0 - Toggle Corrigido");


// ========================================================================
// LÓGICA DE TOGGLE UNIFICADA
// ========================================================================

function toggleSection(targetId) {

    const panel = document.getElementById(
        "mahscript-docs-chapter-panel"
    );

    if (!panel) return;

    const sections = [
        "mahscript-chapters-area",
        "mahscript-settings-section",
        "mahscript-script-area"
    ];

    const target = document.getElementById(targetId);

    if (!target) return;

    // CORREÇÃO PRINCIPAL
    const isCurrentlyVisible =
        window.getComputedStyle(target).display !== "none";

    // fecha tudo
    sections.forEach(id => {
        const el = document.getElementById(id);

        if (el) {
            el.style.display = "none";
        }
    });

    const header = document.querySelector(
        ".mahscript-chapter-header-row"
    );

    const prompt = document.getElementById(
        "mahscript-inline-prompt"
    );

    if (header) {
        header.style.display = "none";
    }

    if (prompt) {
        prompt.style.display = "none";
    }

    // já estava aberto?
    // então permanece fechado
    if (isCurrentlyVisible) {
        return;
    }

    // abre somente a aba escolhida
    target.style.display = "block";

    // -----------------------------
    // CAPÍTULOS
    // -----------------------------
    if (targetId === "mahscript-chapters-area") {

        if (header) {
            header.style.display = "flex";
        }

        if (
            window.mahPanelInstance &&
            typeof window.mahPanelInstance.syncMirror === "function"
        ) {
            window.mahPanelInstance.syncMirror();
        }
    }

    // -----------------------------
    // CONFIGURAÇÕES
    // -----------------------------
    if (
        targetId === "mahscript-settings-section" &&
        typeof renderSettingsForm === "function"
    ) {
        renderSettingsForm();
    }

    // -----------------------------
    // ROTEIRO
    // -----------------------------
    if (
        targetId === "mahscript-script-area" &&
        typeof ensureScriptUI === "function"
    ) {
        ensureScriptUI();
    }
}


// ========================================================================
// BOOT
// ========================================================================

function boot() {

    if (!location.hostname.includes("docs.google.com")) {
        return;
    }

    if (typeof applyMahSkin === "function") {

        const savedSkin =
            localStorage.getItem("mahscript_skin") || "black";

        applyMahSkin(savedSkin);
    }
}


// ========================================================================
// STARTUP
// ========================================================================

if (document.readyState === "loading") {

    document.addEventListener(
        "DOMContentLoaded",
        boot
    );

} else {

    boot();

}


// ========================================================================
// MENSAGENS DO POPUP
// ========================================================================

chrome.runtime.onMessage.addListener((msg) => {

    if (
        msg?.type === "applySkin" &&
        typeof applyMahSkin === "function"
    ) {
        applyMahSkin(msg.skin);
    }

});