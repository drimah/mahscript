console.log("mahscript content.js v9.0 - Arquitetura Modular Correta");

// ========================================================================
// LÓGICA DE TOGGLE UNIFICADA (GERENCIA TODAS AS ABAS)
// ========================================================================
function toggleSection(targetId) {
    const panel = document.getElementById('mahscript-docs-chapter-panel');
    if (!panel) return;
    
    // Lista completa de seções gerenciadas pelo painel
    const sections = [
        'mahscript-chapters-area', 
        'mahscript-settings-section', 
        'mahscript-script-area'
    ];
    
    const target = document.getElementById(targetId);
    if (!target) return;

    const isCurrentlyVisible = target.style.display === 'block';

    // Esconde TODAS as seções primeiro
    sections.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.display = 'none';
    });

    const header = document.querySelector('.mahscript-chapter-header-row');
    const prompt = document.getElementById('mahscript-inline-prompt');
    if (header) header.style.display = 'none';
    if (prompt) prompt.style.display = 'none';

    if (!isCurrentlyVisible) {
        target.style.display = 'block';
        
        // Lógica específica por aba (chamando funções globais dos módulos)
        if (targetId === 'mahscript-chapters-area') {
            if (header) header.style.display = 'flex';
            if(window.mahPanelInstance && typeof window.mahPanelInstance.syncMirror === 'function') {
                window.mahPanelInstance.syncMirror();
            }
        }
        
        if (targetId === 'mahscript-settings-section' && typeof renderSettingsForm === 'function') {
            renderSettingsForm();
        }
        
        // Inicializa a UI do Roteiro quando a aba for aberta
        if (targetId === 'mahscript-script-area' && typeof ensureScriptUI === 'function') {
            ensureScriptUI();
        }
    }
}

// ========================================================================
// BOOT DA EXTENSÃO
// ========================================================================
function boot() {
    if (!location.hostname.includes("docs.google.com")) return;
    
    // Aplica o tema salvo (delega para o theme-manager.js via função global)
    if (typeof applyMahSkin === 'function') {
        const savedSkin = localStorage.getItem('mahscript_skin') || 'black';
        applyMahSkin(savedSkin);
    }
    
    // O MahScriptPanel é instanciado automaticamente pelo panel-builder.js
}

if (document.readyState === "loading") { 
    document.addEventListener("DOMContentLoaded", boot); 
} else { 
    boot(); 
}

// Listener para mensagens do popup (troca de tema em tempo real)
chrome.runtime.onMessage.addListener((msg) => { 
    if (msg?.type === "applySkin" && typeof applyMahSkin === 'function') {
        applyMahSkin(msg.skin); 
    }
});